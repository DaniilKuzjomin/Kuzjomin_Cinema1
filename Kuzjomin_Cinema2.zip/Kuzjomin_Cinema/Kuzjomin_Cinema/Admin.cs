﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Kuzjomin_Cinema
{
    public partial class Admin : Form
    {

        SqlConnection connect = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\opilane\source\repos\Daniil Kuzjomin TARpv21\Kuzjomin_Cinema\Kuzjomin_Cinema\AppData\Cinema.mdf;Integrated Security=True");
        SqlCommand cmd;
        private SqlDataAdapter adapter_toode;
        private object Id;

        public Admin()
        {
            InitializeComponent();
            Naita_Andmed();
        }


        public void Kustuta_Andmed()
        {
            textBox1.Text = "";
            textBox2.Text = "";
            textBox3.Text = "";
            textBox4.Text = "";

        }

        public void Naita_Andmed()
        {
            connect.Open();
            DataTable tbl = new DataTable();
            adapter_toode = new SqlDataAdapter("SELECT * FROM Filmid", connect);
            adapter_toode.Fill(tbl);
            dataGridView1.DataSource = tbl;

            //pictureBox1.Image = Image.FromFile("../../Images/about.png");
            //pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            connect.Close();

        }

        private void kustuta_Click(object sender, EventArgs e)
        {
            {
                if (dataGridView1.SelectedRows.Count == 0)
                    return;

                string sql = "DELETE FROM Filmid WHERE Id = @rowID";

                using (SqlCommand deleteRecord = new SqlCommand(sql, connect))
                {
                    connect.Open();

                    int selectedIndex = dataGridView1.SelectedRows[0].Index;
                    int RowID = Convert.ToInt32(dataGridView1[0, selectedIndex].Value);

                    deleteRecord.Parameters.Add("@rowID", SqlDbType.Int).Value = RowID;
                    deleteRecord.ExecuteNonQuery();

                    dataGridView1.Rows.RemoveAt(selectedIndex);

                    connect.Close();
                }
            }
        }

        private void uuenda_Click(object sender, EventArgs e)
        {
            {

                if (textBox1.Text != "" && textBox2.Text != "" && textBox3.Text != "")
                {
                    try
                    {
                        cmd = new SqlCommand("UPDATE Filmid SET Nimetus=@nimetus, Zanr = @zanr, Kestus = @kestus, Image = @pilt WHERE Id=@Id", connect);
                        connect.Open();
                        cmd.Parameters.AddWithValue("@Id", Id);
                        cmd.Parameters.AddWithValue("@nimetus", textBox1.Text);
                        cmd.Parameters.AddWithValue("@zanr", textBox2.Text); 
                        cmd.Parameters.AddWithValue("@kestus", textBox3.Text);
                        string file_pilt = textBox4.Text;
                        cmd.Parameters.AddWithValue("@pilt", file_pilt);
                        cmd.ExecuteNonQuery();
                        connect.Close();
                        Kustuta_Andmed();
                        Naita_Andmed();
                        MessageBox.Show("Andmed uuendatud");

                    }
                    catch (Exception)
                    {
                        MessageBox.Show("Andmebaasiga viga!");
                    }

                }
                else
                {
                    MessageBox.Show("Sisesta andmeid");
                }
            }
        }

        private void dataGridView1_RowHeaderMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            Id = (int)dataGridView1.Rows[e.RowIndex].Cells[0].Value;
            textBox1.Text = dataGridView1.Rows[e.RowIndex].Cells[1].Value.ToString();
            textBox2.Text = dataGridView1.Rows[e.RowIndex].Cells[2].Value.ToString();
            textBox3.Text = dataGridView1.Rows[e.RowIndex].Cells[3].Value.ToString();
            textBox4.Text = dataGridView1.Rows[e.RowIndex].Cells[4].Value.ToString();

            pictureBox1.Image = System.Drawing.Image.FromFile(@"..\..\images\" + dataGridView1.Rows[e.RowIndex].Cells[4].Value.ToString());

        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (textBox1.Text.Trim() != String.Empty && textBox2.Text.Trim() != String.Empty && textBox3.Text.Trim() != String.Empty)
            {

                cmd = new SqlCommand("INSERT INTO Filmid (Nimetus, Zanr, Kestus, Image) VALUES (@nimetus, @zanr, @kestus, @pilt)", connect);
                connect.Open();
                cmd.Parameters.AddWithValue("@nimetus", textBox1.Text);
                cmd.Parameters.AddWithValue("@zanr", textBox2.Text);
                cmd.Parameters.AddWithValue("@kestus", textBox3.Text); 
                cmd.Parameters.AddWithValue("@pilt", textBox1.Text + ".jpg");

                cmd.ExecuteNonQuery();
                connect.Close();
                Kustuta_Andmed();
                Naita_Andmed();



            }
            else
            {
                MessageBox.Show("Sisesta andmeid");
            }
        }
    }
}
