﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Net.WebRequestMethods;

namespace Kuzjomin_Cinema
{
    public partial class Menu : Form
    {

        SqlConnection connect = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\opilane\source\repos\Daniil Kuzjomin TARpv21\Kuzjomin_Cinema\Kuzjomin_Cinema\AppData\Cinema.mdf;Integrated Security=True");
        SqlCommand cmd;

        private static string st = Application.StartupPath.Remove(Application.StartupPath.IndexOf("bin"));
        public static string db = st.Replace(@"/", "\\") + "Cinema.mdf".Replace(@"/", "\\");
        private Button button1;
        public static string Images = st.Replace(@"\", "/") + "Images/";


        public Menu()
        {
            InitializeComponent();



            int rowsCount = 0;
            bool filmChoosen = false;

            Load += (s, e) =>
            {
                connect.Open();
                SqlCommand sqlCommand = new SqlCommand("SELECT * from Filmid", connect);
                SqlDataReader dataReader = sqlCommand.ExecuteReader();
                while (dataReader.Read())
                {
                    Film filmid = new Film();
                    filmid.Nimetus = dataReader["Nimetus"].ToString();
                    filmid.Zanr = dataReader["Zanr"].ToString();
                    filmid.Kestus = dataReader["Kestus"].ToString();
                    filmid.Image = Images + dataReader["Image"];
                    Film.films.Add(filmid);
                }
                connect.Close();
                for (int i = 0; i < Film.films.Count; i++)
                {
                    PictureBox pbx = new PictureBox();
                    pbx.Location = new Point(20 + i * 220, 60);
                    if (i >= 4 && i != 0)
                    {
                        pbx.Location = new Point(20 + (i % 4) * 220, 300);
                    }
                    pbx.Image = Image.FromFile(Film.films[i].Image);
                    pbx.Tag = Film.films[i].Nimetus.ToString();
                    pbx.Size = new Size(200, 217);
                    pbx.SizeMode = PictureBoxSizeMode.StretchImage;
                    Controls.Add(pbx);
                    pbx.BringToFront();
                }
                void SwitchrowsCount(PictureBox pb)
                {
                    Film.films.ForEach(f =>
                    {
                        if (f.Nimetus.ToLower() == pb.Tag.ToString().ToLower())
                        {
                            rowsCount = f.rowsCount;
                            f.choosen = true;
                        }
                    });
                    foreach (PictureBox box in Controls.OfType<PictureBox>().Where(p => p != pb && p.Name != "pbBG"))
                    {
                        Film.films.Find(f => f.Nimetus.ToLower() == box.Tag.ToString().ToLower()).choosen = false;
                    }
                }
                PictureBox pbm = new PictureBox()
                {
                    Enabled = false,
                    Location = new Point(0, 0),
                    Size = new Size(Size.Width, Size.Height),
                    Image = Image.FromFile($"{Images}fon.jpg"),
                    SizeMode = PictureBoxSizeMode.StretchImage,
                    Name = "pbBG"
                };
                pbm.SendToBack();
                Controls.Add(pbm);
                List<PictureBox> pictures = new List<PictureBox>();
                foreach (PictureBox pb in Controls.OfType<PictureBox>().Where(p => p.Name != "pbBG"))
                {
                    pictures.Add(pb);
                    pb.Click += (ad, be) =>
                    {
                        pictures.ForEach(p => {
                            p.BorderStyle = BorderStyle.None;
                            filmChoosen = false;
                        });
                        pb.BorderStyle = BorderStyle.FixedSingle;
                        SwitchrowsCount(pb);
                        filmChoosen = true;
                    };
                }
                button1.Click += (se, ee) =>
                {
                    if (filmChoosen)
                    {
                        new Information(rowsCount, Film.films.Find(f => f.choosen)).Show();
                        Hide();
                    }
                    else
                    {
                        MessageBox.Show("Valige filmi!");
                    }
                };
            };

        }

        private void InitializeComponent()
        {
            this.button1 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.SystemColors.Window;
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(186)));
            this.button1.ForeColor = System.Drawing.SystemColors.ControlText;
            this.button1.Location = new System.Drawing.Point(271, 544);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(360, 64);
            this.button1.TabIndex = 0;
            this.button1.Text = "Vaata filmi info";
            this.button1.UseVisualStyleBackColor = false;
            // 
            // Menu
            // 
            this.ClientSize = new System.Drawing.Size(904, 620);
            this.Controls.Add(this.button1);
            this.Name = "Menu";
            this.ResumeLayout(false);

        }


    }
}