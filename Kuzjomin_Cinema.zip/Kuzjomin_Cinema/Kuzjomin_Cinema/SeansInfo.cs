﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Kuzjomin_Cinema
{
    public partial class SeansInfo : Form
    {
        // INSERT INTO Seansid(SaalID, Kuupaev, Algab, Lõppeb, KeelID, FilmID, PilettID) VALUES (3, '2012-02-21T18:10:00', '11:00', '12:30', 3, 4, 1)


        SqlConnection connect = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\opilane\source\repos\Daniil Kuzjomin TARpv21\Kuzjomin_Cinema\Kuzjomin_Cinema\AppData\Cinema.mdf;Integrated Security=True");
        SqlCommand cmd = new SqlCommand();







        public SeansInfo()
        {
            int vabad_kohad = 0;
            InitializeComponent();

            Load += (s, e) =>
            {


                seans_vad();
                all_vad();

            };



            
            
        }



        private void seans_vad()
        {

            

            connect.Open();
            DataTable dt = new DataTable();

            SqlCommand command1 = new SqlCommand($"SELECT Algab, Lopeb, SaalID, KeelID, FilmID FROM Seansid WHERE Kuupaev='{monthCalendar1.SelectionRange.Start.ToString()}'", connect);

            SqlDataReader dt1 = command1.ExecuteReader();

            while (dt1.Read())
            {

                comboBox1.Items.Add(dt1.GetValue(0).ToString());
                //label4.Text = dt1.GetValue(0).ToString();
            }
            connect.Close();
        }


        private void all_vad()
        {



            connect.Open();
            DataTable dt = new DataTable();

            SqlCommand command1 = new SqlCommand($"SELECT Algab, Lopeb, SaalID, KeelID, FilmID FROM Seansid WHERE Kuupaev='{monthCalendar1.SelectionRange.Start.ToString()}'", connect);

            SqlDataReader dt1 = command1.ExecuteReader();

            while (dt1.Read())
            {

                label5.Text = dt1.GetValue(2).ToString();
                label8.Text = dt1.GetValue(0).ToString();
                label9.Text = dt1.GetValue(1).ToString();
                //label4.Text = dt1.GetValue(0).ToString();
            }
            connect.Close();
        }


    }
}
