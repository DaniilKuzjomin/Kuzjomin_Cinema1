﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Kuzjomin_Cinema
{
    public class Film
    {
        public static List<Film> films = new List<Film>();
        public int rowsCount;
        public string Nimetus;
        public string Zanr;
        public string Kestus;
        public string Riik;
        public string Image;
        public bool choosen = false;
    }
}
